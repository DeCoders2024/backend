import os
from statistics import mode
from .analysis import Analysis
from django.shortcuts import render,redirect
from django.http import JsonResponse
from .settings import BASE_DIR
def load():
    i=1
    while True:
        yield i
        i+=1

unique=load()

def homePage(request):
    try:
        return render(request,"home.html")
    except Exception as e:
        print(e)
        return JsonResponse({"status":False},status=500)

def predictResultPage(request):
    try:
        if(request.session.get("user",None)):
            fields=request.session['user']['field']
            fields.pop()
            return render(request,"fieldPage.html",{"fields":fields,"target_field":request.session['user']['target_field']})
        return render(request,"predictResult.html")
    except Exception as e:
        print(e)
        return JsonResponse({"status":False},status=500)

def reset(request):
    try:
        if(request.session['user']):
            model=request.session['user']
            removeFile(model['filename'])
            del request.session['user']
            return redirect("/predictResult")
        raise Exception("Error...")
    except Exception as e:
        print(e)
        return redirect("/")
def predictField(request):
    train_filename=f"{BASE_DIR}/files/{next(unique)}.csv"
    try:
        data=request.POST
        files=request.FILES
        if(not files['train_data'].name.endswith(".csv")):
            return redirect("/")
        if(not uploadFile(train_filename,files['train_data'])):
            raise Exception("Upload Error....")
        model=Analysis(train_filename,data['target_field'])
        field=model.extractFieldName()
        request.session['user']={"model":data['model'],"target_field":data['target_field'],"filename":train_filename,"field":field}
        field.pop()
        return render(request,"fieldPage.html",{"fields":field,"target_field":data['target_field']})
    except Exception as e:
        print(e)
        return redirect("/predictResult")
    
def predictOutPut(request):
    try:
        if(not request.session.get("user",None)):
            return JsonResponse({"status":False})
        var=request.session['user']
        fields=[float(item) for item in request.GET['q'].split(",")]
        model=Analysis(var['filename'],var['target_field'])
        output,val=model.predict(var["model"],fields)
        return JsonResponse({"status":True,"output":output,"value":val},status=200)
    except Exception as e:
        print(e)
        return JsonResponse({"status":False,"error":"Server Error.."},status=500)


def findModel(request):
    train_filename=f"{BASE_DIR}/files/{next(unique)}.csv"
    try:
        data=request.POST
        files=request.FILES
        if(not files['train_data'].name.endswith(".csv")):
            return redirect("/")
        if(not uploadFile(train_filename,files['train_data'])):
            raise Exception("Upload Error....")
        model=Analysis(train_filename,data['target_field'])
        models={"1":"Decision Tree","2":"Logistic Regression","3":"Random Forest","4":"Gradient Boosting"}
        res={"modelS":models[data['model']],"filename":files['train_data'].name,"target_field":data['target_field']}
        res.update(model.algorithm())
        res.update(model.detail())
        res.update(model.modelAccuracy(data['model']))
        removeFile(train_filename)
        return render(request,"output.html",res)
    except Exception as e:
        print(e)
        removeFile(train_filename)
        return redirect("/")

def uploadFile(filename,file):
    try:
        with open(filename,"wb") as f:
            for chunk in file.chunks():
                f.write(chunk)
        return True
    except Exception as e:
        print(e)
        return False

def removeFile(*filenames):
    try:
        for filename in filenames:
            try:
                os.remove(filename)
            except Exception as e:
                print(e)
    except Exception as e:
        print(e)