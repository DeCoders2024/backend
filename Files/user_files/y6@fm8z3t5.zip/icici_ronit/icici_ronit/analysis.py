import pandas as pd
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
class Analysis:
    def __init__(self,filename,target):
        self.df=pd.read_csv(filename)
        colums=self.df.columns
        for col in colums:
            if(self.df[col].dtype==object):
                self.df.drop([col],axis=1,inplace=True)
        columns=self.df.columns

        imputer = SimpleImputer(missing_values = np.nan,
                            strategy ='median')
        imputer = imputer.fit(self.df)
        self.df=pd.DataFrame(imputer.transform(self.df),columns=columns)
        self.target=target

    def randomForest(self,x_train,x_test,y_train,y_test):
        try:
            model=RandomForestClassifier()
            model.fit(x_train,y_train)
            pred1=model.predict(x_test)
            acc=accuracy_score(y_test,pred1)
            return acc
        except Exception as e:
            print(e)
            return 0
    def predict(self,model,fields):
        fields=np.array([fields])
        models={"1":DecisionTreeClassifier(),"2":LogisticRegression(),"3":RandomForestClassifier(),"4":GradientBoostingClassifier()}
        x_train,y_train=self.predictdataSet()
        print(x_train.shape)
        model=models[model]
        model.fit(x_train,y_train)
        output=model.predict_proba(fields)
        output=abs(output[0][1]*100)
        if(output>=50):
            s=1
        else:
            s=0
        return [output,s]
    def predictdataSet(self):
        train_y=self.df[self.target].to_numpy()
        train_x=self.df.drop([self.target],axis=1).to_numpy()
        return train_x,train_y
    def extractFieldName(self):
        field_name=self.df.columns.to_list()
        l=[]
        d={"LOAN":"Amount of the loan request","MORTDUE":"Amount due on existing mortgage","VALUE":"Value of current property","REASON":"DebtCon = debt consolidation HomeImp = home improvement","JOB":"Six occupational categories","YOJ":"Years at present job","DEROG":"Number of major derogatory reports","DELINQ":"Number of delinquent credit lines","CLAGE":"Age of oldest trade line in months"}
        for i in range(len(field_name)):
            l.append([i,field_name[i],d.get(field_name[i],"")])
        field_name=l
        for i in range(len(field_name)):
            if(field_name[i][1]==self.target):
                field_name[-1],field_name[i]=field_name[i],field_name[-1]
                break
        return field_name
    
    def LogisticRegression(self,x_train,x_test,y_train,y_test):
        try:
            model=LogisticRegression()
            model.fit(x_train,y_train)
            pred2=model.predict(x_test)
            acc=accuracy_score(y_test,pred2)
            return acc
        except Exception as e:
            print(e)
            return 0
    
    def DecisionTree(self,x_train,x_test,y_train,y_test):
        try:
            model=DecisionTreeClassifier()
            model.fit(x_train,y_train)
            pred3=model.predict(x_test)
            acc=accuracy_score(y_test,pred3)
            return acc
        except Exception as e:
            print(e)
            return 0

    def boosting(self,x_train,x_test,y_train,y_test):
        try:
            parameters = {
                            'max_depth': range (2, 10, 1),
                            'n_estimators': range(60, 220, 40),
                            'learning_rate': [0.1, 0.01, 0.05]
                        }
                        
            model = XGBClassifier()
            model.fit(x_train,y_train,verbose = False)
            pred3=model.predict(x_test)
            acc=accuracy_score(y_test,pred3)
            return acc
        except Exception as e:
            print(e)
            return 0
    
    def algorithm(self):
        try:
            x_train,x_test,y_train,y_test=self.dataSplit()


            acc2=self.LogisticRegression(x_train,x_test,y_train,y_test)
            print(acc2)
            acc3=self.DecisionTree(x_train,x_test,y_train,y_test)
            print(acc3)
            # acc4=self.boosting(x_train,x_test,y_train,y_test)
            # print(acc4)
            acc4=0
            acc1=self.randomForest(x_train,x_test,y_train,y_test)
            print(acc1)
            a={"Decision Tree":acc3,"Logistic Regression":acc2,"Random Forest":acc1,"Gradient Boosting":acc4}
            self.result=a
            maxVal="Gradient Boosting"

            for model in a:
                if(a[model]>a[maxVal]):
                    maxVal=model
            print(maxVal)
            return {"model":maxVal,"val":a[maxVal]}
        
        except Exception as e:
            print(e)
            return {"model":"ML Error","val":0}

    def detail(self):
        row,features=self.df.shape
        return {"rows":row,"features":features-1}

    def modelAccuracy(self,model):
        try:
            models={"1":"Decision Tree","2":"Logistic Regression","3":"Random Forest","4":"Gradient Boosting"}
            return {"predict":self.result[models[model]]}
        except Exception as e:
            print(e)
            return 0

    def dataSplit(self):
        df=pd.get_dummies(self.df)
        columns=df.columns
        imputer = SimpleImputer(missing_values = np.nan,
                            strategy ='median')
        imputer = imputer.fit(df)
        df=pd.DataFrame(imputer.transform(df))
        df.columns=columns
        scalar=StandardScaler()
        X=df.drop(self.target,axis=1)
        X_std=scalar.fit_transform(X)
        Y=df[self.target]
        x_train,x_test,y_train,y_test=train_test_split(X_std,Y,test_size=0.5,random_state=12345)
        return x_train,x_test,y_train,y_test
    
