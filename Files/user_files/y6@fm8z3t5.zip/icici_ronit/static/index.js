let inputFileds=Array.from(document.getElementsByClassName("fields"))
let s_form=document.querySelector("#s-form")
// let outputTag=document.querySelector(".output")
let valueTag=document.querySelector(".value")

inputFileds.map((item)=>{
    item.addEventListener("keyup",()=>{
        // outputTag.value="None";
        valueTag.value="None";
    })
})

const handleSubmit=async(e)=>{
    e.preventDefault();
    let arr=[]
    for(let i=0;i<=inputFileds.length;i++){
        arr.push(null);
    }
    for(let i=0;i<inputFileds.length;i++){
        let tag=inputFileds[i];
        let id=parseInt(tag.id)
        arr[id]=(tag.value);
    }
    arr=arr.filter((val)=>{
        if(val){
            return true;
        }
        return false;
    })
    let res=await fetch(`/predictOutput/?q=${arr}`);
    res=await res.json();
    if(res.status){
        // outputTag.value=res.output+"%";
        valueTag.value=res.value;
    }
    else{
        alert("Server Error...")
    }
}

s_form.addEventListener("submit",handleSubmit);